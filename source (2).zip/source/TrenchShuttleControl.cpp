#include "TrenchShuttleControl.h"

namespace trench
{

TrenchShuttleControl::TrenchShuttleControl (juce::RangedAudioParameter& param,
                                            juce::String label,
                                            bool primary)
    : parameter (param),
      attachment (param, [this] (float v) { onParameterChanged (v); }),
      labelText (label),
      isPrimary (primary),
      defaultValue01 (primary ? 0.729f : 0.0f)
{
    setOpaque (false);
    setPaintingIsUnclipped(true); // Allow drawing label above bounds
    setMouseCursor (juce::MouseCursor::LeftRightResizeCursor);
    attachment.sendInitialUpdate();
}

TrenchShuttleControl::~TrenchShuttleControl() = default;

void TrenchShuttleControl::onParameterChanged (float newDenormValue)
{
    const auto v01 = clamp01 (toNorm (newDenormValue));
    if (! juce::approximatelyEqual (v01, currentValue01))
    {
        currentValue01 = v01;
        repaint(); // Will repaint label and track
    }
}

void TrenchShuttleControl::commitValue (float v01)
{
    v01 = clamp01 (v01);
    currentValue01 = v01;
    attachment.setValueAsPartOfGesture (toDenorm (v01));
    repaint();
}

void TrenchShuttleControl::mouseDown (const juce::MouseEvent& e)
{
    dragging = true;
    dragStartValue01 = currentValue01;
    dragStartX = e.x;
    attachment.beginGesture();
}

void TrenchShuttleControl::mouseDrag (const juce::MouseEvent& e)
{
    if (! dragging)
        return;

    const float gain = e.mods.isShiftDown() ? 0.25f : 1.0f;
    const float dx = static_cast<float> (e.x - dragStartX) / static_cast<float> (juce::jmax (1, getWidth()));
    commitValue (dragStartValue01 + dx * gain);
}

void TrenchShuttleControl::mouseUp (const juce::MouseEvent&)
{
    if (dragging)
    {
        dragging = false;
        attachment.endGesture();
    }
}

void TrenchShuttleControl::mouseDoubleClick (const juce::MouseEvent&)
{
    attachment.setValueAsCompleteGesture (toDenorm (defaultValue01));
}

void TrenchShuttleControl::mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails& w)
{
    if (std::abs (w.deltaY) <= 0.0f)
        return;

    attachment.setValueAsCompleteGesture (toDenorm (clamp01 (currentValue01 + (w.deltaY > 0.0f ? 0.02f : -0.02f))));
}

float TrenchShuttleControl::toDenorm(float v01) const noexcept 
{ 
    return parameter.getNormalisableRange().convertFrom0to1(v01); 
}

float TrenchShuttleControl::toNorm(float denorm) const noexcept 
{ 
    return parameter.getNormalisableRange().convertTo0to1(denorm); 
}

float TrenchShuttleControl::clamp01(float v) noexcept 
{ 
    return juce::jlimit(0.0f, 1.0f, v); 
}

void TrenchShuttleControl::paint (juce::Graphics& g)
{
    // Draw the label ABOVE the bounds
    g.setFont (style::mono(10.5f, true));
    g.setColour (juce::Colours::white.withAlpha (0.88f));
    g.drawText (labelText, 0, -24, getWidth(), 18, juce::Justification::centred, false);

    // Draw the travel line inside the bounds
    auto r = getLocalBounds().toFloat();
    if (r.isEmpty())
        return;

    auto lane = r.reduced (r.getWidth() * 0.065f, r.getHeight() * 0.34f);
    lane.setHeight (juce::jmax (3.0f, lane.getHeight()));
    lane.setWidth (juce::jmax (2.0f, lane.getWidth() * currentValue01));

    if (lane.getWidth() <= 0.5f)
        return;

    auto accentColour = isPrimary ? style::aqua() : style::aquaDim();
    
    g.setColour (accentColour.withAlpha (0.22f));
    g.fillRoundedRectangle (lane.expanded (3.0f, 2.0f), 2.0f);

    g.setColour (accentColour);
    g.fillRoundedRectangle (lane, 1.5f);

    g.setColour (juce::Colours::white.withAlpha (0.20f));
    g.drawHorizontalLine (juce::roundToInt (lane.getY()), lane.getX(), lane.getRight());
}

}
