#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>

namespace trench
{

class TrenchValueBox final : public juce::Component,
                             private juce::Timer
{
public:
    enum class Mode { Percent, Raw };

    explicit TrenchValueBox (juce::RangedAudioParameter& param, Mode m = Mode::Percent)
        : parameter (param), mode (m)
    {
        setOpaque (false);
        startTimerHz (24);
    }

    void paint (juce::Graphics& g) override
    {
        const float v01 = parameter.getValue();
        const juce::String text = mode == Mode::Percent
            ? juce::String (v01 * 100.0f, 1)
            : juce::String (parameter.convertFrom0to1 (v01), 2);

        g.setFont (juce::Font (juce::FontOptions ("Courier New", 17.0f, juce::Font::bold)));
        g.setColour (juce::Colour (0xff080a0c).withAlpha (0.92f));
        g.drawText (text, getLocalBounds(), juce::Justification::centred, false);
    }

private:
    void timerCallback() override { repaint(); }

    juce::RangedAudioParameter& parameter;
    Mode mode;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TrenchValueBox)
};

} // namespace trench
