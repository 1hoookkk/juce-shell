#pragma once

#include <juce_gui_basics/juce_gui_basics.h>

namespace trench::ui
{
    // Canonical faceplate asset dimensions (source space).
    static constexpr float sourceW = 1800.0f;
    static constexpr float sourceH = 2702.0f;

    // Runtime editor sizes.
    static constexpr int defaultEditorW = 480;
    static constexpr int defaultEditorH = 721;
    static constexpr int largeEditorW   = 600;
    static constexpr int largeEditorH   = 901;

    // Active runtime size — default is 480x721.
    static constexpr int editorW = defaultEditorW;
    static constexpr int editorH = defaultEditorH;

    // Scale factors: source-space → runtime pixels.
    inline float sx() noexcept { return static_cast<float> (editorW) / sourceW; }
    inline float sy() noexcept { return static_cast<float> (editorH) / sourceH; }

    inline juce::Rectangle<float> fromSource (float x, float y, float w, float h) noexcept
    {
        return { x * sx(), y * sy(), w * sx(), h * sy() };
    }

    inline juce::Point<float> pointFromSource (float x, float y) noexcept
    {
        return { x * sx(), y * sy() };
    }

    inline juce::Rectangle<int> snap (juce::Rectangle<float> r) noexcept
    {
        return r.getSmallestIntegerContainer();
    }

    // Source-space geometry (1800x2702 reference).
    inline juce::Rectangle<float> topSlot()      noexcept { return fromSource (292.5f, 230.0f,  1215.0f, 102.0f); }
    inline juce::Rectangle<float> display()      noexcept { return fromSource (225.0f, 435.0f,  1350.0f, 715.0f); }
    inline juce::Rectangle<float> morphWell()    noexcept { return fromSource (212.0f, 1302.0f,  920.0f, 146.0f); }
    inline juce::Rectangle<float> qWell()        noexcept { return fromSource (212.0f, 1554.0f,  920.0f, 146.0f); }
    inline juce::Rectangle<float> morphReadout() noexcept { return fromSource (1260.0f, 1314.0f, 296.0f, 121.0f); }
    inline juce::Rectangle<float> qReadout()     noexcept { return fromSource (1260.0f, 1566.0f, 296.0f, 121.0f); }

    inline juce::Rectangle<float> labelAbove (juce::Rectangle<float> well) noexcept
    {
        return { well.getX(), well.getY() - 24.0f, well.getWidth(), 18.0f };
    }
}
