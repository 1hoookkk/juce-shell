#pragma once

#include "PluginProcessor.h"
#include "BinaryData.h"

#include "TrenchUiGeometry.h"
#include "TrenchBodySelector.h"
#include "TrenchResponseDisplay.h"
#include "TrenchShuttleControl.h"
#include "TrenchValueBox.h"

#include <juce_gui_basics/juce_gui_basics.h>

class PluginEditor final : public juce::AudioProcessorEditor
{
public:
    explicit PluginEditor (PluginProcessor&);
    ~PluginEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    PluginProcessor& processorRef;
    juce::Image faceplateImg;

    std::unique_ptr<trench::TrenchBodySelector> bodySelector;
    std::unique_ptr<trench::TrenchResponseDisplay> responseDisplay;
    std::unique_ptr<trench::TrenchShuttleControl> morphControl;
    std::unique_ptr<trench::TrenchShuttleControl> qControl;
    std::unique_ptr<trench::TrenchValueBox> morphValue;
    std::unique_ptr<trench::TrenchValueBox> qValue;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PluginEditor)
};
