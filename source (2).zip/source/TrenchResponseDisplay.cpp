#include "TrenchResponseDisplay.h"

#include <cmath>

namespace trench
{

TrenchResponseDisplay::TrenchResponseDisplay (TrenchDspBridge& bridge)
    : dspBridge (bridge)
{
    setOpaque (false);
    startTimerHz (30);
}

TrenchResponseDisplay::~TrenchResponseDisplay() = default;

void TrenchResponseDisplay::timerCallback()
{
    repaint();
}

void TrenchResponseDisplay::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();

    // Removed the "fucking box in the display" (the pinkWash background and clip)
    // The faceplate asset already draws the glass. We only draw the faint grid and trace.

    // Grid.
    g.setColour (juce::Colours::black.withAlpha (0.18f));
    for (int i = 1; i < 10; ++i)
    {
        const float x = r.getX() + r.getWidth() * (float) i / 10.0f;
        g.drawVerticalLine (juce::roundToInt (x), r.getY() + 3.0f, r.getBottom() - 3.0f);
    }

    g.setColour (juce::Colours::white.withAlpha (0.055f));
    g.drawHorizontalLine (juce::roundToInt (r.getCentreY()), r.getX() + 3.0f, r.getRight() - 3.0f);

    float coeffs[30]{};
    float boost = 1.0f;
    dspBridge.getSmoothedCoeffsForUI (coeffs, boost);

    juce::Path trace;
    const int width = juce::jmax (2, juce::roundToInt (r.getWidth()));
    const float sampleRate = static_cast<float> (TrenchRates::emuInternalRate);

    for (int i = 0; i < width; ++i)
    {
        const float t = (float) i / (float) (width - 1);
        const float freq = 20.0f * std::pow (20000.0f / 20.0f, t);
        const float omega = 2.0f * juce::MathConstants<float>::pi * freq / sampleRate;

        const float cosW  = std::cos (omega);
        const float sinW  = std::sin (omega);
        const float cos2W = std::cos (2.0f * omega);
        const float sin2W = std::sin (2.0f * omega);

        float mag = juce::jmax (1.0e-6f, boost);

        for (int s = 0; s < 6; ++s)
        {
            const float* c = &coeffs[s * 5];

            const float numReal = c[0] + c[1] * cosW + c[2] * cos2W;
            const float numImag = -(c[1] * sinW + c[2] * sin2W);

            const float denReal = 1.0f + c[3] * cosW + c[4] * cos2W;
            const float denImag = -(c[3] * sinW + c[4] * sin2W);

            const float denMagSq = denReal * denReal + denImag * denImag;

            if (denMagSq > 1.0e-12f)
                mag *= std::sqrt ((numReal * numReal + numImag * numImag) / denMagSq);
        }

        const float db = juce::jlimit (-72.0f, 36.0f,
            20.0f * std::log10 (juce::jmax (1.0e-8f, mag)));

        const float y = juce::jmap (db, -60.0f, 30.0f,
                                    r.getBottom() - 8.0f,
                                    r.getY() + 8.0f);

        if (i == 0)
            trace.startNewSubPath (r.getX() + (float) i, y);
        else
            trace.lineTo (r.getX() + (float) i, y);
    }

    g.setColour (style::cyanTrace());
    g.strokePath (trace, juce::PathStrokeType (1.75f));
}

}
