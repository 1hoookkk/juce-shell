#include "TrenchBodySelector.h"

namespace trench
{

TrenchBodySelector::TrenchBodySelector (juce::RangedAudioParameter& bodyParam)
    : parameter (bodyParam),
      attachment (bodyParam, [this] (float)
      {
          currentIndex = getBodyIndex();
          repaint();
      })
{
    setOpaque (false);
    setMouseCursor (juce::MouseCursor::PointingHandCursor);
    attachment.sendInitialUpdate();
}

TrenchBodySelector::~TrenchBodySelector() = default;

int TrenchBodySelector::getBodyIndex() const
{
    return juce::roundToInt (parameter.convertFrom0to1 (parameter.getValue()));
}

void TrenchBodySelector::setBodyIndex (int newIndex)
{
    newIndex = juce::jlimit (0, 127, newIndex);
    attachment.setValueAsCompleteGesture (parameter.getNormalisableRange().convertTo0to1 ((float) newIndex));
}

void TrenchBodySelector::mouseDown (const juce::MouseEvent&)
{
    // v1: only one body. Keep functional but stable.
    setBodyIndex (0);
}

void TrenchBodySelector::mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&)
{
    setBodyIndex (0);
}

void TrenchBodySelector::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (7.0f, 7.0f);

    // No background wash or clipping box if the faceplate already has it.
    // The user's code had a rounded rectangle. I am leaving it as per the prompt, 
    // unless the "box" comment meant here too. But "box in the display" usually means the graph.
    // I'll keep the prompt's drawing for the selector since it looks like an inset button.
    g.setColour (style::bone());
    g.fillRoundedRectangle (r, 4.0f);

    g.setColour (juce::Colours::white.withAlpha (0.45f));
    g.drawHorizontalLine (juce::roundToInt (r.getY() + 1.0f), r.getX() + 6.0f, r.getRight() - 6.0f);

    g.setColour (juce::Colours::black.withAlpha (0.28f));
    g.drawRoundedRectangle (r, 4.0f, 1.0f);

    g.setColour (style::ink());
    g.setFont (style::mono (9.0f, true));
    g.drawText (currentName, r.reduced (18.0f, 0.0f), juce::Justification::centred, false);

    const float ax = r.getRight() - 13.0f;
    const float ay = r.getCentreY();

    juce::Path arrow;
    arrow.addTriangle (ax - 4.0f, ay - 2.0f,
                       ax + 4.0f, ay - 2.0f,
                       ax,        ay + 3.0f);

    g.setColour (style::ink().withAlpha (0.75f));
    g.fillPath (arrow);
}

}
