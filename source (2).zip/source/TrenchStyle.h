#pragma once

#include <juce_gui_basics/juce_gui_basics.h>

namespace trench::style
{
    inline juce::Colour aqua()      { return juce::Colour (0xff58f4ff); }
    inline juce::Colour aquaDim()   { return juce::Colour (0xff58f4ff).withAlpha (0.36f); }
    inline juce::Colour bone()      { return juce::Colour (0xffeee9dc); }
    inline juce::Colour ink()       { return juce::Colour (0xff0b1115); }
    inline juce::Colour pinkWash()  { return juce::Colour (0xff260018).withAlpha (0.28f); }
    inline juce::Colour cyanTrace() { return juce::Colour (0xff52fff1); } // Back-compat if needed

    inline juce::Font mono (float size, bool bold = false)
    {
        return juce::Font (juce::FontOptions ("Courier New", size,
            bold ? juce::Font::bold : juce::Font::plain));
    }
}
