#pragma once

#include "TrenchStyle.h"

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>

namespace trench
{

class TrenchBodySelector final : public juce::Component
{
public:
    explicit TrenchBodySelector (juce::RangedAudioParameter& bodyParam);
    ~TrenchBodySelector() override;

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;

private:
    void setBodyIndex (int newIndex);
    int getBodyIndex() const;

    juce::RangedAudioParameter& parameter;
    juce::ParameterAttachment attachment;

    juce::String currentName { "SPEAKER KNOCKERZ" };
    int currentIndex = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TrenchBodySelector)
};

}
