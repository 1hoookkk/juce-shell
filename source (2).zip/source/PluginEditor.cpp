#include "PluginEditor.h"

PluginEditor::PluginEditor (PluginProcessor& p)
    : AudioProcessorEditor (&p), processorRef (p)
{
    setOpaque (true);
    setSize (trench::ui::editorW, trench::ui::editorH);

    faceplateImg = juce::ImageFileFormat::loadFrom (
        BinaryData::final_plate_png,
        BinaryData::final_plate_pngSize);

    auto* bodyParam  = processorRef.apvts.getParameter (ParamID::body);
    auto* morphParam = processorRef.apvts.getParameter (ParamID::morph);
    auto* qParam     = processorRef.apvts.getParameter (ParamID::q);

    jassert (bodyParam != nullptr);
    jassert (morphParam != nullptr);
    jassert (qParam != nullptr);

    bodySelector = std::make_unique<trench::TrenchBodySelector> (*bodyParam);
    addAndMakeVisible (*bodySelector);

    responseDisplay = std::make_unique<trench::TrenchResponseDisplay> (processorRef.dspBridge);
    addAndMakeVisible (*responseDisplay);

    morphControl = std::make_unique<trench::TrenchShuttleControl> (*morphParam, "MORPH", true);
    qControl     = std::make_unique<trench::TrenchShuttleControl> (*qParam, "Q", false);

    addAndMakeVisible (*morphControl);
    addAndMakeVisible (*qControl);

    morphValue = std::make_unique<trench::TrenchValueBox> (*morphParam);
    qValue     = std::make_unique<trench::TrenchValueBox> (*qParam);

    addAndMakeVisible (*morphValue);
    addAndMakeVisible (*qValue);
}

PluginEditor::~PluginEditor() = default;

void PluginEditor::paint (juce::Graphics& g)
{
    if (faceplateImg.isValid())
        g.drawImage (faceplateImg, getLocalBounds().toFloat(), juce::RectanglePlacement::stretchToFit);
    else
        g.fillAll (juce::Colour (0xff061123));
}

void PluginEditor::resized()
{
    bodySelector->setBounds    (trench::ui::snap (trench::ui::topSlot()));
    responseDisplay->setBounds (trench::ui::snap (trench::ui::display()));

    morphControl->setBounds    (trench::ui::snap (trench::ui::morphWell()));
    qControl->setBounds        (trench::ui::snap (trench::ui::qWell()));

    morphValue->setBounds      (trench::ui::snap (trench::ui::morphReadout()));
    qValue->setBounds          (trench::ui::snap (trench::ui::qReadout()));
}
