#pragma once

#include "dsp/TrenchDspBridge.h"
#include "TrenchRates.h"
#include "TrenchStyle.h"

#include <juce_gui_basics/juce_gui_basics.h>

namespace trench
{

class TrenchResponseDisplay final : public juce::Component,
                                    private juce::Timer
{
public:
    explicit TrenchResponseDisplay (TrenchDspBridge& bridge);
    ~TrenchResponseDisplay() override;

    void paint (juce::Graphics&) override;

private:
    void timerCallback() override;

    TrenchDspBridge& dspBridge;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TrenchResponseDisplay)
};

}
