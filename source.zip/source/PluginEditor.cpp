#include "PluginEditor.h"
#include "BinaryData.h"
#include "TrenchValueBox.h"

namespace
{
    static constexpr float kAssetW = 480.0f;
    static constexpr float kAssetH = 720.0f;
}

PluginEditor::PluginEditor (PluginProcessor& p)
    : AudioProcessorEditor (&p), processorRef (p)
{
    juce::LookAndFeel::setDefaultLookAndFeel (&lnf);
    setLookAndFeel (&lnf);

    faceplateImg = juce::ImageFileFormat::loadFrom (BinaryData::final_plate_png, BinaryData::final_plate_pngSize);
    
    // Core runtime UI size 480x720 from 1800x2700 @3.75x ratio
    setSize (480, 720);

    auto setupShuttle = [this](std::unique_ptr<trench::TrenchShuttleControl>& shuttle, const juce::String& paramID, juce::Colour col) {
        if (auto* param = processorRef.apvts.getParameter(paramID)) {
            shuttle = std::make_unique<trench::TrenchShuttleControl>(*param, col);
            addAndMakeVisible(shuttle.get());
        }
    };

    setupShuttle(morphShuttle, ParamID::morph, juce::Colour(0xff58d4f0));
    setupShuttle(qShuttle, ParamID::q, juce::Colour(0xff2a6a78)); // dimmer than morph

    auto setupReadout = [this](std::unique_ptr<trench::TrenchValueBox>& readout, const juce::String& paramID) {
        if (auto* param = processorRef.apvts.getParameter(paramID)) {
            readout = std::make_unique<trench::TrenchValueBox>(*param);
            addAndMakeVisible(readout.get());
        }
    };

    setupReadout(morphReadout, ParamID::morph);
    setupReadout(qReadout, ParamID::q);

    // Inspector button - hidden in top-right mechanical detail
    addAndMakeVisible (inspectButton);
    inspectButton.setButtonText("");
    inspectButton.setAlpha(0.0f); // Hidden but clickable
    inspectButton.onClick = [&] {
        if (!inspector)
        {
            inspector = std::make_unique<melatonin::Inspector> (*this);
            inspector->onClose = [this]() { inspector.reset(); };
        }
        inspector->setVisible (true);
    };
}

PluginEditor::~PluginEditor()
{
}

void PluginEditor::paint (juce::Graphics& g)
{
    const auto bounds = getLocalBounds().toFloat();
    if (faceplateImg.isValid())
    {
        g.drawImage (faceplateImg, bounds, juce::RectanglePlacement::stretchToFit);
    }
    else
    {
        g.fillAll (juce::Colour(0xff070809));
    }

    // --- Top Slot Body Name ---
    g.setColour(juce::Colours::white.withAlpha(0.85f));
    g.setFont(juce::Font(juce::FontOptions("Courier New", 16.0f, juce::Font::bold)));
    // 3x top slot ~ 1215x102. Centered horizontally: x = 292.5.
    // In asset, the upper dark slot scans from Y=230 to Y=331.
    auto topSlotArea = from3x(292.5f, 230.0f, 1215.0f, 102.0f);
    g.drawText("<  SPEAKER KNOCKERZ  >", topSlotArea, juce::Justification::centred);

    // --- Spectrum Trace Restoration ---
    const auto displayArea = from3x(225.0f, 435.0f, 1350.0f, 715.0f);
    
    // Draw dark translucent overlay over pink display
    {
        juce::Path viewport;
        viewport.addRoundedRectangle(displayArea, 6.0f);
        g.saveState();
        g.reduceClipRegion(viewport);
        
        // Dark translucent magenta wash
        g.fillAll(juce::Colour(0xff30001a).withAlpha(0.70f));
        
        // Faint grid
        g.setColour(juce::Colours::white.withAlpha(0.04f));
        for (int i = 1; i < 10; ++i) {
            float x = displayArea.getX() + displayArea.getWidth() * (i / 10.0f);
            g.drawVerticalLine(juce::roundToInt(x), displayArea.getY(), displayArea.getBottom());
        }
        
        // Faint horizontal reference line
        g.drawHorizontalLine(juce::roundToInt(displayArea.getCentreY()), displayArea.getX(), displayArea.getRight());

        // --- Live Trace ---
        float coeffs[30]; // 6 stages * 5 coeffs
        float boost = 1.0f;
        processorRef.dspBridge.getSmoothedCoeffsForUI(coeffs, boost);

        juce::Path trace;
        const int width = juce::roundToInt(displayArea.getWidth());
        const float sampleRate = 44100.0f; // Canonical rate

        for (int i = 0; i < width; ++i)
        {
            float freq = 20.0f * std::pow(20000.0f / 20.0f, i / (float)width);
            float omega = 2.0f * juce::MathConstants<float>::pi * freq / sampleRate;
            float cosW = std::cos(omega);
            float cos2W = std::cos(2.0f * omega);
            float sinW = std::sin(omega);
            float sin2W = std::sin(2.0f * omega);

            float mag = boost;
            for (int s = 0; s < 6; ++s)
            {
                float* c = &coeffs[s * 5];
                float numReal = c[0] + c[1] * cosW + c[2] * cos2W;
                float numImag = -(c[1] * sinW + c[2] * sin2W);
                float denReal = 1.0f + c[3] * cosW + c[4] * cos2W;
                float denImag = -(c[3] * sinW + c[4] * sin2W);
                float denMagSq = denReal * denReal + denImag * denImag;
                if (denMagSq > 1e-12f)
                    mag *= std::sqrt((numReal * numReal + numImag * numImag) / denMagSq);
            }

            float db = 20.0f * std::log10(std::max(1e-6f, mag));
            float y = juce::jmap(db, -60.0f, 30.0f, displayArea.getBottom() - 10.0f, displayArea.getY() + 10.0f);
            
            if (i == 0) trace.startNewSubPath(displayArea.getX() + i, y);
            else trace.lineTo(displayArea.getX() + i, y);
        }

        g.setColour(juce::Colour(0xff33fff0)); // Pale cyan / electric aqua
        g.strokePath(trace, juce::PathStrokeType(2.5f)); // Thicker, instrument-like trace
        
        g.restoreState();
    }

    if (isMeasuring)
    {
        // ... (measurement drawing code)
    }
}

void PluginEditor::resized()
{
    inspectButton.setBounds (10, 10, 60, 20);

    // Wells: from3x(212, 1302, 920, 146)
    // Readouts: from3x(1260, 1314, 296, 121)
    
    auto layoutRow = [&](int row, std::unique_ptr<trench::TrenchShuttleControl>& shuttle, std::unique_ptr<trench::TrenchValueBox>& readout) {
        float y_3x = 1302.0f + row * 252.0f;
        if (shuttle != nullptr) shuttle->setBounds(from3x(212, y_3x, 920, 146).getSmallestIntegerContainer());
        if (readout != nullptr) readout->setBounds(from3x(1260, y_3x + 12.0f, 296, 121).getSmallestIntegerContainer());
    };

    layoutRow(0, morphShuttle, morphReadout);
    layoutRow(1, qShuttle, qReadout);
}

void PluginEditor::mouseDown (const juce::MouseEvent& e)
{
    if (e.mods.isAltDown())
    {
        dragger.startDraggingComponent (e.eventComponent, e);
    }
    else if (e.mods.isCtrlDown())
    {
        isMeasuring = true;
        marqueeStart = e.getPosition();
        marqueeEnd = marqueeStart;
        repaint();
    }
}

void PluginEditor::mouseDrag (const juce::MouseEvent& e)
{
    if (e.mods.isAltDown())
    {
        dragger.dragComponent (e.eventComponent, e, nullptr);
    }
    else if (isMeasuring)
    {
        marqueeEnd = e.getPosition();
        repaint();
    }
}

void PluginEditor::mouseUp (const juce::MouseEvent&)
{
    if (isMeasuring)
    {
        const float sx = (float)getWidth() / kAssetW;
        const float sy = (float)getHeight() / kAssetH;
        auto r = juce::Rectangle<int>(marqueeStart, marqueeEnd).toFloat();
        
        DBG ("RECT: " << r.getX()/sx << ", " << r.getY()/sy << ", " << r.getWidth()/sx << ", " << r.getHeight()/sy);
        isMeasuring = false;
        repaint();
    }
}

bool PluginEditor::keyPressed (const juce::KeyPress& k)
{
    if (k.getTextCharacter() == 'p' || k.getTextCharacter() == 'P')
    {
        const float sx = (float)getWidth() / kAssetW;
        const float sy = (float)getHeight() / kAssetH;
        
        DBG ("--- COMPONENT POSITIONS ---");
        for (auto* child : getChildren())
        {
            auto r = child->getBounds().toFloat();
            DBG (child->getName() << ": " << r.getX()/sx << ", " << r.getY()/sy << ", " << r.getWidth()/sx << ", " << r.getHeight()/sy);
        }
        return true;
    }
    return false;
}
