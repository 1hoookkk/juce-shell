#include "TrenchShuttleControl.h"
#include <cmath>

namespace trench
{

TrenchShuttleControl::TrenchShuttleControl (juce::RangedAudioParameter& param,
                                            juce::Colour accent,
                                            float op,
                                            float defaultValue)
    : parameter (param),
      attachment (param, [this] (float v) { onParameterChanged (v); }),
      accentColour (accent),
      defaultValue01 (clamp01 (defaultValue)),
      opacity (op)
{
    setMouseCursor (juce::MouseCursor::LeftRightResizeCursor);
    setOpaque (false);
    setWantsKeyboardFocus (false);
    attachment.sendInitialUpdate();
}

TrenchShuttleControl::~TrenchShuttleControl() = default;

void TrenchShuttleControl::onParameterChanged (float newDenormValue)
{
    const float v01 = clamp01 (toNorm (newDenormValue));
    if (! juce::approximatelyEqual (v01, currentValue01))
    {
        currentValue01 = v01;
        repaint();
    }
}

void TrenchShuttleControl::commitValue (float v01)
{
    v01 = clamp01 (v01);
    if (juce::approximatelyEqual (v01, currentValue01)) return;
    currentValue01 = v01;
    attachment.setValueAsPartOfGesture (toDenorm (v01));
    repaint();
}

void TrenchShuttleControl::mouseDown (const juce::MouseEvent& e)
{
    dragging = true;
    dragStartValue01 = currentValue01;
    dragStartX = e.x;
    attachment.beginGesture();
}

void TrenchShuttleControl::mouseDrag (const juce::MouseEvent& e)
{
    if (! dragging) return;
    const float w = static_cast<float> (juce::jmax (1, getWidth()));
    const float gain = e.mods.isShiftDown() ? 0.25f : 1.0f;
    const float deltaT = static_cast<float> (e.x - dragStartX) / w * gain;
    commitValue (dragStartValue01 + deltaT);
}

void TrenchShuttleControl::mouseUp (const juce::MouseEvent&)
{
    if (dragging)
    {
        attachment.endGesture();
        dragging = false;
    }
}

void TrenchShuttleControl::mouseDoubleClick (const juce::MouseEvent&)
{
    attachment.setValueAsCompleteGesture (toDenorm (defaultValue01));
}

void TrenchShuttleControl::mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails& w)
{
    if (juce::approximatelyEqual (w.deltaY, 0.0f)) return;
    const float step = w.deltaY > 0.0f ? 0.02f : -0.02f;
    attachment.setValueAsCompleteGesture (toDenorm (clamp01 (currentValue01 + step)));
}

void TrenchShuttleControl::paint (juce::Graphics& g)
{
    const auto bounds = getLocalBounds().toFloat();
    if (bounds.isEmpty()) return;

    const auto well = bounds.reduced (1.0f, 1.0f);

    // No background drawing: the faceplate bakes the black wells.

    // Simple code-drawn cyan travel bar.
    const float paddingX = well.getWidth() * 0.05f;
    const float paddingY = well.getHeight() * 0.35f;
    const float barH = well.getHeight() - paddingY * 2.0f;
    const float maxW = well.getWidth() - paddingX * 2.0f;
    const float fillW = juce::jmax(2.0f, maxW * currentValue01);

    // Draw the bright cyan fill
    g.setColour (accentColour.withAlpha (opacity));
    g.fillRect (well.getX() + paddingX, well.getY() + paddingY, fillW, barH);
}

} // namespace trench
