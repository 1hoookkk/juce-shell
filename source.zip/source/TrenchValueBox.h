#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>

namespace trench
{

class TrenchValueBox : public juce::Component, public juce::Timer
{
public:
    TrenchValueBox (juce::RangedAudioParameter& param)
        : parameter (param)
    {
        startTimer (50);
    }

    void paint (juce::Graphics& g) override
    {
        auto bounds = getLocalBounds().toFloat();
        
        g.setColour (juce::Colours::black.withAlpha(0.9f));
        g.setFont (juce::Font(juce::FontOptions("Courier New", 18.0f, juce::Font::bold)));
        
        float v = parameter.getValue(); // 0 to 1
        juce::String text;
        if (parameter.getName(10).toLowerCase().contains("morph")) {
            text = "M " + juce::String(juce::roundToInt(v * 100));
        } else {
            text = "Q " + juce::String(parameter.convertFrom0to1(v), 2);
        }
        
        g.drawText (text, bounds, juce::Justification::centred);
    }

private:
    void timerCallback() { repaint(); }
    juce::RangedAudioParameter& parameter;
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TrenchValueBox)
};

} // namespace trench
