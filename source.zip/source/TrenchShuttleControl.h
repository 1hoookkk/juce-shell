#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>

namespace trench
{

// Recessed horizontal travel-well slider with a solid moving carriage.
// Replaces the old juce::Slider + LookAndFeel route used for Morph/Q so the
// faceplate's black wells read as tactile hardware shuttles.
//
//   * Drag is relative (mouseDown captures anchor, drag accumulates delta).
//   * Shift = 0.25x gain.
//   * Wheel steps in 0.02 increments.
//   * Double-click resets to defaultValue01.
//   * Hit target is the entire well.
class TrenchShuttleControl : public juce::Component
{
public:
    TrenchShuttleControl (juce::RangedAudioParameter& param,
                          juce::Colour accent,
                          float opacity = 1.0f,
                          float defaultValue01 = 0.5f);
    ~TrenchShuttleControl() override;

    void paint (juce::Graphics& g) override;

    void mouseDown (const juce::MouseEvent& e) override;
    void mouseDrag (const juce::MouseEvent& e) override;
    void mouseUp (const juce::MouseEvent& e) override;
    void mouseDoubleClick (const juce::MouseEvent& e) override;
    void mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& w) override;

private:
    void onParameterChanged (float newDenormValue);
    void commitValue (float v01);
    float toDenorm (float v01) const noexcept { return parameter.getNormalisableRange().convertFrom0to1 (v01); }
    float toNorm (float v) const noexcept { return parameter.getNormalisableRange().convertTo0to1 (v); }
    static float clamp01 (float v) noexcept { return juce::jlimit (0.0f, 1.0f, v); }

    juce::RangedAudioParameter& parameter;
    juce::ParameterAttachment attachment;
    juce::Colour accentColour;
    float defaultValue01 { 0.5f };
    float opacity { 1.0f };

    float currentValue01 { 0.0f };

    bool dragging { false };
    float dragStartValue01 { 0.0f };
    int dragStartX { 0 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TrenchShuttleControl)
};

} // namespace trench
