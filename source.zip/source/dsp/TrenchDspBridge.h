#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

extern "C" {
    void* trench_engine_create();
    void trench_engine_destroy(void* engine);
    void trench_engine_prepare(void* engine, double sampleRate);
    int trench_engine_load_cartridge(void* engine, const char* json);
    void trench_engine_set_parameters(void* engine, float morph, float q, float slamDrive, float fiveD);
    void trench_engine_process_block(void* engine, float* left, float* right, int numSamples, double morph, double q);
    void trench_engine_get_coeffs(void* engine, float* outCoeffs, float* outBoost);
}

struct TrenchParams
{
    float morph;
    float q;
    float slamDrive;
    float fiveD;
};

class TrenchDspBridge
{
public:
    TrenchDspBridge()
    {
        engine = trench_engine_create();
    }

    ~TrenchDspBridge()
    {
        trench_engine_destroy(engine);
    }

    void prepare(double sampleRate, int /*maxBlockSize*/)
    {
        trench_engine_prepare(engine, sampleRate);
    }

    void loadCartridge(const juce::String& json)
    {
        trench_engine_load_cartridge(engine, json.toRawUTF8());
    }

    void setParameters(const TrenchParams& params)
    {
        trench_engine_set_parameters(engine, params.morph, params.q, params.slamDrive, params.fiveD);
    }

    void process(juce::AudioBuffer<float>& buffer, const TrenchParams& params)
    {
        if (buffer.getNumChannels() < 2) return;
        
        trench_engine_process_block(engine, 
                                    buffer.getWritePointer(0), 
                                    buffer.getWritePointer(1), 
                                    buffer.getNumSamples(), 
                                    params.morph / 100.0, 
                                    params.q / 100.0);
    }

    void getSmoothedCoeffsForUI(float* outCoeffs, float& outBoost)
    {
        trench_engine_get_coeffs(engine, outCoeffs, &outBoost);
    }

    void reset() 
    {
        // Internal reset handled by process and prepare
    }

private:
    void* engine = nullptr;
};