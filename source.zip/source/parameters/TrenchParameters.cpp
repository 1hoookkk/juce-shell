#include "parameters/TrenchParameters.h"

namespace TrenchParameters
{

juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ParamID::morph, 1},
        "Morph",
        juce::NormalisableRange<float>{0.0f, 1.0f, 0.001f},
        0.0f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ParamID::q, 1},
        "Q",
        juce::NormalisableRange<float>{0.0f, 1.0f, 0.001f},
        0.0f));

    layout.add(std::make_unique<juce::AudioParameterInt>(
        juce::ParameterID{ParamID::body, 1},
        "Body",
        0, 127,
        0));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ParamID::trim, 1},
        "Trim",
        juce::NormalisableRange<float>{-48.0f, 12.0f, 0.1f},
        0.0f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ParamID::slamDrive, 1},
        "Drive",
        juce::NormalisableRange<float>{0.0f, 1.0f, 0.001f},
        0.0f));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{ParamID::fiveD, 1},
        "5D",
        juce::NormalisableRange<float>{0.0f, 1.0f, 0.001f},
        0.0f));

    return layout;
}

} // namespace TrenchParameters