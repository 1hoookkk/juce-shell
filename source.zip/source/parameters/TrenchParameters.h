#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

namespace ParamID
{
    inline constexpr auto morph = "morph";
    inline constexpr auto q = "q";
    inline constexpr auto body = "body";
    inline constexpr auto trim = "trim";
    inline constexpr auto slamDrive = "slamDrive";
    inline constexpr auto fiveD = "fiveD";
}

namespace TrenchParameters
{

juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

} // namespace TrenchParameters