#pragma once

#include "PluginProcessor.h"
#include "BinaryData.h"
#include "TrenchValueBox.h"
#include <juce_gui_basics/juce_gui_basics.h>
#include "melatonin_inspector/melatonin_inspector.h"
#include "TrenchShuttleControl.h"
#include "TrenchLookAndFeel.h"

//==============================================================================
class PluginEditor : public juce::AudioProcessorEditor
{
public:
    explicit PluginEditor (PluginProcessor&);
    ~PluginEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;
    
    // Developer Tooling Overrides
    void mouseDown (const juce::MouseEvent& e) override;
    void mouseDrag (const juce::MouseEvent& e) override;
    void mouseUp (const juce::MouseEvent& e) override;
    bool keyPressed (const juce::KeyPress& k) override;

    static constexpr float kAssetScale = 3.75f;
    static juce::Rectangle<float> from3x (float x, float y, float w, float h)
    {
        return { x / kAssetScale, y / kAssetScale, w / kAssetScale, h / kAssetScale };
    }

private:
    PluginProcessor& processorRef;
    std::unique_ptr<melatonin::Inspector> inspector;
    juce::TextButton inspectButton { "Inspect" };

    juce::Image faceplateImg;
    
    trench::TrenchLookAndFeel lnf;
    std::unique_ptr<trench::TrenchShuttleControl> morphShuttle;
    std::unique_ptr<trench::TrenchShuttleControl> qShuttle;

    std::unique_ptr<trench::TrenchValueBox> morphReadout;
    std::unique_ptr<trench::TrenchValueBox> qReadout;

    // Measurement Tool state
    bool isMeasuring = false;
    juce::Point<int> marqueeStart, marqueeEnd;

    // Dragger for UI prototyping (Alt-Drag)
    juce::ComponentDragger dragger;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PluginEditor)
};
