#pragma once

#include <juce_gui_basics/juce_gui_basics.h>

namespace trench
{

class TrenchLookAndFeel : public juce::LookAndFeel_V4
{
public:
    static juce::Colour cVoid()      { return juce::Colour (0xff070809); }
    static juce::Colour cChassis()   { return juce::Colour (0xff14191c); }
    static juce::Colour cTrough()    { return juce::Colour (0xff060809); }
    static juce::Colour cEdge()      { return juce::Colour (0xff1a2123); }
    static juce::Colour cEdgeHi()    { return juce::Colour (0xff2a3438); }
    static juce::Colour cBone()      { return juce::Colour (0xffe5dccb); }
    static juce::Colour cBoneDim()   { return juce::Colour (0xff9aa096); }
    static juce::Colour cAccent()    { return juce::Colour (0xff58d4f0); }
    static juce::Colour cAccentDim() { return juce::Colour (0xff6f9cab); }

    TrenchLookAndFeel()
    {
        setColour (juce::ResizableWindow::backgroundColourId, cChassis());
        setColour (juce::Label::textColourId, cBone());
        setColour (juce::Label::backgroundColourId, juce::Colours::transparentBlack);
        setColour (juce::TextButton::buttonColourId, cTrough());
        setColour (juce::TextButton::buttonOnColourId, cAccent().withAlpha (0.18f));
        setColour (juce::TextButton::textColourOnId, cAccent());
        setColour (juce::TextButton::textColourOffId, cBone());
        setColour (juce::ComboBox::backgroundColourId, cTrough());
        setColour (juce::ComboBox::outlineColourId, cEdge());
        setColour (juce::ComboBox::textColourId, cBone());
        setColour (juce::ComboBox::arrowColourId, cBoneDim());
        setColour (juce::ComboBox::buttonColourId, cTrough());
        setColour (juce::PopupMenu::backgroundColourId, cChassis());
        setColour (juce::PopupMenu::textColourId, cBone());
        setColour (juce::PopupMenu::highlightedBackgroundColourId, cAccent().withAlpha (0.22f));
        setColour (juce::PopupMenu::highlightedTextColourId, cAccent());
        setColour (juce::Slider::backgroundColourId, cTrough());
        setColour (juce::Slider::trackColourId, cAccent());
        setColour (juce::Slider::thumbColourId, cBone());
        setColour (juce::Slider::textBoxBackgroundColourId, cTrough());
        setColour (juce::Slider::textBoxTextColourId, cBone());
        setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour (juce::TextEditor::backgroundColourId, cTrough());
        setColour (juce::TextEditor::textColourId, cBone());
        setColour (juce::TextEditor::outlineColourId, cEdge());
        setColour (juce::TextEditor::focusedOutlineColourId, cAccent().withAlpha (0.6f));
        setColour (juce::CaretComponent::caretColourId, cAccent());
    }

    juce::Font getLabelFont (juce::Label& l) override
    {
        return juce::Font (juce::FontOptions ("Consolas", l.getHeight() * 0.6f, juce::Font::plain));
    }

    juce::Font getComboBoxFont (juce::ComboBox& box) override
    {
        return juce::Font (juce::FontOptions ("Consolas", juce::jmax (10.0f, box.getHeight() * 0.55f), juce::Font::plain));
    }

    juce::Font getPopupMenuFont() override
    {
        return juce::Font (juce::FontOptions ("Consolas", 13.0f, juce::Font::plain));
    }

    juce::Font getTextButtonFont (juce::TextButton&, int buttonHeight) override
    {
        return juce::Font (juce::FontOptions ("Consolas", juce::jmax (11.0f, buttonHeight * 0.42f), juce::Font::bold));
    }

    void drawButtonBackground (juce::Graphics& g, juce::Button& b,
                               const juce::Colour& /*backgroundColour*/,
                               bool over, bool down) override
    {
        const auto bounds = b.getLocalBounds().toFloat().reduced (0.5f);
        g.setColour (down ? cAccent().withAlpha (0.12f)
                          : (over ? cChassis().brighter (0.05f) : cTrough()));
        g.fillRect (bounds);
        g.setColour (down ? cAccent() : (over ? cAccent().withAlpha (0.7f) : cEdge()));
        g.drawRect (bounds, 1.0f);
    }

    void drawButtonText (juce::Graphics& g, juce::TextButton& b,
                         bool over, bool down) override
    {
        g.setFont (getTextButtonFont (b, b.getHeight()));
        g.setColour (down ? cAccent()
                          : (over ? cBone() : b.findColour (juce::TextButton::textColourOffId)));
        g.drawText (b.getButtonText(), b.getLocalBounds(), juce::Justification::centred, false);
    }

    void drawComboBox (juce::Graphics& g, int width, int height,
                       bool /*isButtonDown*/, int /*buttonX*/, int /*buttonY*/,
                       int /*buttonW*/, int /*buttonH*/, juce::ComboBox& box) override
    {
        const auto bounds = juce::Rectangle<float> (0, 0, (float) width, (float) height).reduced (0.5f);
        g.setColour (box.findColour (juce::ComboBox::backgroundColourId));
        g.fillRect (bounds);
        g.setColour (box.isMouseOver (true) ? cAccent().withAlpha (0.7f) : box.findColour (juce::ComboBox::outlineColourId));
        g.drawRect (bounds, 1.0f);

        const float caretX = bounds.getRight() - height * 0.55f;
        const float caretY = bounds.getCentreY();
        const float s = height * 0.18f;
        juce::Path caret;
        caret.addTriangle (caretX - s, caretY - s * 0.5f,
                           caretX + s, caretY - s * 0.5f,
                           caretX,     caretY + s * 0.6f);
        g.setColour (box.findColour (juce::ComboBox::arrowColourId));
        g.fillPath (caret);
    }

    void drawPopupMenuBackground (juce::Graphics& g, int width, int height) override
    {
        g.fillAll (cChassis());
        g.setColour (cEdge());
        g.drawRect (0, 0, width, height, 1);
    }

    void drawPopupMenuItem (juce::Graphics& g, const juce::Rectangle<int>& area,
                            bool isSeparator, bool isActive, bool isHighlighted,
                            bool isTicked, bool /*hasSubMenu*/, const juce::String& text,
                            const juce::String& /*shortcut*/, const juce::Drawable* /*icon*/,
                            const juce::Colour* /*textColourToUse*/) override
    {
        if (isSeparator)
        {
            g.setColour (cEdge());
            g.drawHorizontalLine (area.getCentreY(), (float) area.getX() + 4, (float) area.getRight() - 4);
            return;
        }
        if (isHighlighted && isActive)
        {
            g.setColour (cAccent().withAlpha (0.20f));
            g.fillRect (area);
        }
        g.setColour (! isActive ? cBoneDim().withAlpha (0.5f)
                                : (isHighlighted ? cAccent() : cBone()));
        g.setFont (getPopupMenuFont());
        const auto textArea = area.reduced (10, 0);
        g.drawText (text, textArea, juce::Justification::centredLeft, true);
        if (isTicked)
        {
            g.setColour (cAccent());
            g.fillRect (area.getX() + 4, area.getCentreY() - 1, 4, 2);
        }
    }

    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPos, float minSliderPos, float maxSliderPos,
                           const juce::Slider::SliderStyle style, juce::Slider& slider) override
    {
        if (style != juce::Slider::LinearHorizontal && style != juce::Slider::LinearBar)
        {
            juce::LookAndFeel_V4::drawLinearSlider (g, x, y, width, height,
                                                    sliderPos, minSliderPos, maxSliderPos, style, slider);
            return;
        }

        const float h = (float) height;
        const float w = (float) width;
        const auto accent = slider.findColour (juce::Slider::trackColourId);

        const float troughH = h * 0.50f;
        const auto trough = juce::Rectangle<float> ((float) x, (float) y + (h - troughH) * 0.5f, w, troughH);

        g.setColour (cTrough());
        g.fillRect (trough);

        g.setColour (juce::Colours::black.withAlpha (0.85f));
        g.fillRect (juce::Rectangle<float> (trough.getX() + 1.0f, trough.getY(),
                                            trough.getWidth() - 2.0f, 1.5f));

        g.setColour (juce::Colours::white.withAlpha (0.06f));
        g.drawHorizontalLine (juce::roundToInt (trough.getCentreY()),
                              trough.getX() + 4.0f, trough.getRight() - 4.0f);

        g.setColour (juce::Colours::white.withAlpha (0.04f));
        for (int i = 1; i < 5; ++i)
        {
            const float tx = juce::jmap (static_cast<float> (i) / 5.0f,
                                         trough.getX() + 3.0f, trough.getRight() - 3.0f);
            g.drawLine (tx, trough.getY() + trough.getHeight() * 0.35f,
                        tx, trough.getBottom() - trough.getHeight() * 0.35f, 1.0f);
        }

        g.setColour (cEdge());
        g.drawRect (trough, 1.0f);

        const float xMin = trough.getX() + 2.0f;
        const float xMax = trough.getRight() - 2.0f;
        const float fillX = juce::jlimit (xMin, xMax, sliderPos);
        const auto band = juce::Rectangle<float> (xMin,
                                                  trough.getY() + 2.0f,
                                                  juce::jmax (0.0f, fillX - xMin),
                                                  trough.getHeight() - 4.0f);
        if (band.getWidth() > 0.5f)
        {
            g.setColour (accent);
            g.fillRect (band);
        }

        const bool over = slider.isMouseOverOrDragging();
        const float capW = juce::jmax (14.0f, h * 0.46f);
        const float capH = h * 0.98f;
        const auto cap = juce::Rectangle<float> (fillX - capW * 0.5f,
                                                 (float) y + (h - capH) * 0.5f,
                                                 capW, capH);

        g.setColour (juce::Colours::black.withAlpha (0.62f));
        g.fillRect (cap.translated (0.0f, 1.5f));
        g.setColour (juce::Colours::black.withAlpha (0.30f));
        g.fillRect (cap.translated (0.0f, 2.5f));

        const auto capBody = over ? juce::Colour (0xfff2ebde) : juce::Colour (0xffd9d0bf);
        g.setColour (capBody);
        g.fillRect (cap);

        g.setColour (juce::Colours::white.withAlpha (0.32f));
        g.fillRect (juce::Rectangle<float> (cap.getX(), cap.getY(), cap.getWidth(), 1.0f));
        g.setColour (juce::Colours::white.withAlpha (0.16f));
        g.fillRect (juce::Rectangle<float> (cap.getX(), cap.getY() + 1.0f, cap.getWidth(), 1.0f));

        g.setColour (juce::Colours::black.withAlpha (0.50f));
        g.fillRect (juce::Rectangle<float> (cap.getX(), cap.getBottom() - 1.0f, cap.getWidth(), 1.0f));
        g.setColour (juce::Colours::black.withAlpha (0.22f));
        g.fillRect (juce::Rectangle<float> (cap.getX(), cap.getBottom() - 2.0f, cap.getWidth(), 1.0f));

        g.setColour (juce::Colours::white.withAlpha (0.20f));
        g.fillRect (juce::Rectangle<float> (cap.getX(), cap.getY() + 1.0f, 1.0f, cap.getHeight() - 2.0f));
        g.setColour (juce::Colours::black.withAlpha (0.28f));
        g.fillRect (juce::Rectangle<float> (cap.getRight() - 1.0f, cap.getY() + 1.0f, 1.0f, cap.getHeight() - 2.0f));

        const float windowW = juce::jmax (3.5f, capW * 0.34f);
        const float windowH = capH * 0.46f;
        const auto window = juce::Rectangle<float> (cap.getCentreX() - windowW * 0.5f,
                                                    cap.getCentreY() - windowH * 0.5f,
                                                    windowW, windowH);
        g.setColour (juce::Colour (0xff050708));
        g.fillRect (window.expanded (0.5f));
        g.setColour (accent);
        g.fillRect (window);
        g.setColour (juce::Colours::white.withAlpha (0.20f));
        g.fillRect (juce::Rectangle<float> (window.getX(), window.getY(), window.getWidth(), 0.6f));

        const float ridgeY1 = cap.getY() + cap.getHeight() * 0.30f;
        const float ridgeY2 = cap.getY() + cap.getHeight() * 0.70f;
        const float ridgeXL = cap.getX() + 2.0f;
        const float ridgeXR = window.getX() - 1.5f;
        if (ridgeXR - ridgeXL > 1.0f)
        {
            g.setColour (juce::Colours::black.withAlpha (0.30f));
            g.fillRect (juce::Rectangle<float> (ridgeXL, ridgeY1, ridgeXR - ridgeXL, 1.0f));
            g.fillRect (juce::Rectangle<float> (ridgeXL, ridgeY2, ridgeXR - ridgeXL, 1.0f));
            g.fillRect (juce::Rectangle<float> (window.getRight() + 1.5f, ridgeY1,
                                                cap.getRight() - window.getRight() - 3.0f, 1.0f));
            g.fillRect (juce::Rectangle<float> (window.getRight() + 1.5f, ridgeY2,
                                                cap.getRight() - window.getRight() - 3.0f, 1.0f));
        }

        g.setColour (juce::Colours::black.withAlpha (0.78f));
        g.drawRect (cap, 1.0f);
    }

    void drawLabel (juce::Graphics& g, juce::Label& label) override
    {
        g.fillAll (label.findColour (juce::Label::backgroundColourId));
        if (! label.isBeingEdited())
        {
            g.setColour (label.findColour (juce::Label::textColourId));
            g.setFont (getLabelFont (label));
            const auto area = label.getLocalBounds().reduced (label.getBorderSize().getLeft(), 0);
            g.drawFittedText (label.getText(), area, label.getJustificationType(),
                              juce::jmax (1, (int) (label.getHeight() / getLabelFont (label).getHeight())));
        }
    }

private:
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TrenchLookAndFeel)
};

} // namespace trench
